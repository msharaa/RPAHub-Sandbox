package UTL
{
    class MyScript { 
    function Hello(name) { return "welcome to ServiceNow!"; }
}
}